const Contacts = require('./contacts');

module.exports = { Contacts };